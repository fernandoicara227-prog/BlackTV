package com.blacktv.player

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import java.util.concurrent.Executors

data class Entry(val name:String, val url:String, val group:String)

class MainActivity : Activity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var urlInput: EditText
    private lateinit var status: TextView
    private lateinit var list: LinearLayout
    private lateinit var search: EditText
    private lateinit var category: Spinner
    private var entries = listOf<Entry>()
    private var selectedGroup = "Todos"
    private val worker = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("blacktv", MODE_PRIVATE) }
    private val blue = Color.rgb(0,126,255)
    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5,9,20)
        window.navigationBarColor = Color.rgb(5,9,20)
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14)); setBackgroundColor(Color.rgb(5,9,20)) }
        root.addView(TextView(this).apply {
            text="BLACK TV"; textSize=29f; gravity=Gravity.CENTER; setTextColor(Color.WHITE)
            typeface=android.graphics.Typeface.DEFAULT_BOLD; setPadding(0,dp(8),0,dp(10))
        }, match())
        playerView = PlayerView(this).apply { useController=true; setBackgroundColor(Color.BLACK) }
        root.addView(playerView, LinearLayout.LayoutParams(-1,dp(215)))
        urlInput = EditText(this).apply {
            hint="URL da lista M3U ou stream M3U8"; setTextColor(-1); setHintTextColor(Color.LTGRAY)
            singleLine=true; textSize=15f; setPadding(dp(12)); background=bg(Color.rgb(25,34,52))
            setText(prefs.getString("playlist",""))
        }
        root.addView(urlInput, matchTop(54))
        root.addView(button("CARREGAR LISTA") { loadPlaylist(urlInput.text.toString().trim()) }, matchTop())
        root.addView(button("REPRODUZIR URL DIRETA") { play(urlInput.text.toString().trim()) }, matchTop())
        status = TextView(this).apply { text="Adicione sua lista M3U autorizada."; setTextColor(Color.LTGRAY); textSize=13f; setPadding(0,dp(8),0,dp(5)) }
        root.addView(status, match())
        search = EditText(this).apply {
            hint="Buscar canal, filme ou série"; setTextColor(-1); setHintTextColor(Color.LTGRAY)
            singleLine=true; setPadding(dp(10)); background=bg(Color.rgb(25,34,52))
            addTextChangedListener(SimpleWatcher { render() })
        }
        root.addView(search, matchTop(48))
        category = Spinner(this)
        root.addView(category, matchTop())
        category.onItemSelectedListener = object: android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent:android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent:android.widget.AdapterView<*>?, view:android.view.View?, position:Int, id:Long) {
                selectedGroup = parent?.getItemAtPosition(position)?.toString() ?: "Todos"; render()
            }
        }
        val scroll=ScrollView(this)
        list=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        player=ExoPlayer.Builder(this).build()
        playerView.player=player
        urlInput.setOnEditorActionListener { _,_,_ -> play(urlInput.text.toString().trim()); true }
        if (urlInput.text.toString().startsWith("http")) loadPlaylist(urlInput.text.toString().trim())
    }

    private fun loadPlaylist(raw:String) {
        if (!raw.startsWith("https://") && !raw.startsWith("http://")) {
            status.text="Informe uma URL http(s) válida."; return
        }
        status.text="Carregando lista..."
        prefs.edit().putString("playlist",raw).apply()
        worker.execute {
            try {
                val body=URL(raw).openConnection().apply { connectTimeout=15000; readTimeout=25000 }
                    .getInputStream().bufferedReader().use { it.readText() }
                val parsed=parseM3u(body)
                runOnUiThread {
                    entries=parsed
                    val groups=listOf("Todos")+parsed.map{it.group}.distinct().filter{it.isNotBlank()}.sorted()
                    category.adapter=ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, groups)
                    status.text="${parsed.size} itens carregados."
                    render()
                }
            } catch(e:Exception) {
                runOnUiThread { status.text="Erro ao abrir a lista. Confira o link e a conexão." }
            }
        }
    }

    private fun parseM3u(body:String):List<Entry> {
        val out=mutableListOf<Entry>()
        var name="Canal"; var group="Outros"
        body.lineSequence().forEach { line ->
            val s=line.trim()
            if(s.startsWith("#EXTINF",true)) {
                name=s.substringAfterLast(",", "Canal").trim().ifBlank{"Canal"}
                val g=Regex("""group-title="([^"]*)"""").find(s)?.groupValues?.get(1)
                group=g?.ifBlank{"Outros"} ?: "Outros"
            } else if(s.startsWith("http://") || s.startsWith("https://")) {
                out.add(Entry(name,s,group)); name="Canal"; group="Outros"
            }
        }
        return out
    }

    private fun render() {
        if(!::list.isInitialized) return
        list.removeAllViews()
        val q=if(::search.isInitialized) search.text.toString().trim().lowercase() else ""
        val filtered=entries.filter {
            (selectedGroup=="Todos" || it.group==selectedGroup) &&
            (q.isBlank() || it.name.lowercase().contains(q) || it.group.lowercase().contains(q))
        }
        filtered.take(1000).forEach { item ->
            list.addView(button("${item.name}  •  ${item.group}") { play(item.url) }, matchTop())
        }
        if(filtered.isEmpty()) list.addView(TextView(this).apply {
            text=if(entries.isEmpty()) "Sua lista aparecerá aqui." else "Nenhum resultado encontrado."
            setTextColor(Color.LTGRAY); setPadding(dp(8))
        }, match())
    }

    private fun play(raw:String) {
        if(!raw.startsWith("https://") && !raw.startsWith("http://")) {
            status.text="Digite uma URL http(s) válida."; return
        }
        try {
            player?.setMediaItem(MediaItem.fromUri(raw)); player?.prepare(); player?.playWhenReady=true
            status.text="Reproduzindo conteúdo selecionado."
        } catch(e:Exception) { status.text="Não foi possível reproduzir esse endereço." }
    }

    private fun button(label:String, action:()->Unit)=Button(this).apply {
        text=label; textSize=14f; isAllCaps=false; setTextColor(Color.WHITE)
        backgroundTintList=android.content.res.ColorStateList.valueOf(blue)
        isFocusable=true; isFocusableInTouchMode=true; setOnClickListener{action()}
    }
    private fun bg(color:Int)=android.graphics.drawable.GradientDrawable().apply { setColor(color); cornerRadius=dp(9).toFloat() }
    private fun match()=LinearLayout.LayoutParams(-1,-2)
    private fun matchTop(height:Int=-2)=LinearLayout.LayoutParams(-1,height).apply { topMargin=dp(7) }
    override fun onDestroy() { playerView.player=null; player?.release(); player=null; worker.shutdown(); super.onDestroy() }
}

class SimpleWatcher(val changed:()->Unit): android.text.TextWatcher {
    override fun beforeTextChanged(s:CharSequence?, start:Int, count:Int, after:Int) {}
    override fun onTextChanged(s:CharSequence?, start:Int, before:Int, count:Int) { changed() }
    override fun afterTextChanged(s:android.text.Editable?) {}
}
